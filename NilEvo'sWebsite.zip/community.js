/* ══════════════════════════════════════
   AquaMind Community JS — Nested Replies
══════════════════════════════════════ */
(function () {
'use strict';

var currentPage  = 1;
var currentSort  = 'new';
var activePostId = null;
var totalPages   = 1;
var replyingTo   = null; // { id, author } — للـ nested reply

/* ── Hardcoded translations (independent of script.js load order) ── */
var CM_TRANSLATIONS = {
    en: {
        cm_reply_submit:    'Reply',
        cm_reply_ph:        'Write a reply...',
        cm_reply_ph_inline: 'Write your reply... (Ctrl+Enter to send)',
        cm_replying_to:     'Replying to',
        cm_empty:           'No posts yet. Be the first!',
        cm_ago_s: 'just now', cm_ago_m: 'm ago', cm_ago_h: 'h ago', cm_ago_d: 'd ago',
        cm_likes: 'likes', cm_replies: 'Replies',
        cm_premium_badge:   '👑 Premium',
        cm_login_nudge:     'Join the community —',
        cm_login_link:      'Sign in to post',
        cm_translate:       'Translate',
        cm_show_original:   'Show original',
        cm_translating:     'Translating...'
    },
    ar: {
        cm_reply_submit:    'رد',
        cm_reply_ph:        'اكتب رداً...',
        cm_reply_ph_inline: 'اكتب ردك... (Ctrl+Enter للإرسال)',
        cm_replying_to:     'رداً على',
        cm_empty:           'لا توجد منشورات بعد. كن الأول!',
        cm_ago_s: 'الآن', cm_ago_m: 'د', cm_ago_h: 'س', cm_ago_d: 'ي',
        cm_likes: 'إعجاب', cm_replies: 'الردود',
        cm_premium_badge:   '👑 مميز',
        cm_login_nudge:     'انضم للمجتمع —',
        cm_login_link:      'سجّل دخولك للنشر',
        cm_translate:       'ترجم',
        cm_show_original:   'عرض الأصلي',
        cm_translating:     'جاري الترجمة...'
    }
};

/* ── Language state — initialized immediately, no dependency on script.js ── */
var cmLang = localStorage.getItem('language') || 'en';
var cmT = CM_TRANSLATIONS[cmLang] || CM_TRANSLATIONS.en;

/* ── Called by script.js when language changes ── */
window.cmSetLanguage = function(lang, t) {
    cmLang = lang;
    // استخدم الترجمات الـ hardcoded أولاً، وdمرج مع أي ترجمات إضافية من script.js
    cmT = Object.assign({}, CM_TRANSLATIONS[lang] || CM_TRANSLATIONS.en, t || {});

    // placeholder inputs بالـ data-key-ph
    document.querySelectorAll('[data-key-ph]').forEach(function(el) {
        var key = el.getAttribute('data-key-ph');
        if (cmT[key]) el.placeholder = cmT[key];
    });

    // placeholders مباشرة
    var titleInp = document.getElementById('cmPostTitle');
    if (titleInp && cmT.cm_np_title_ph) titleInp.placeholder = cmT.cm_np_title_ph;
    var bodyInp = document.getElementById('cmPostBody');
    if (bodyInp && cmT.cm_np_body_ph) bodyInp.placeholder = cmT.cm_np_body_ph;
    var replyInp = document.getElementById('cmReplyBody');
    if (replyInp && cmT.cm_reply_ph) replyInp.placeholder = cmT.cm_reply_ph;

    // re-render feed with new language
    loadPosts(currentPage, currentSort);
};

/* ── Helpers ── */
function timeAgo(d) {
    var s = (Date.now() - new Date(d)) / 1000;
    var isAr = cmLang === 'ar';
    if (s < 60)    return cmT.cm_ago_s || 'just now';
    if (s < 3600) {
        var m = Math.floor(s/60);
        return isAr ? m + ' ' + (cmT.cm_ago_m||'د') : m + (cmT.cm_ago_m||'m ago');
    }
    if (s < 86400) {
        var h = Math.floor(s/3600);
        return isAr ? h + ' ' + (cmT.cm_ago_h||'س') : h + (cmT.cm_ago_h||'h ago');
    }
    var dd = Math.floor(s/86400);
    return isAr ? dd + ' ' + (cmT.cm_ago_d||'ي') : dd + (cmT.cm_ago_d||'d ago');
}
function av(name) { return (name||'?').trim().charAt(0).toUpperCase(); }
function esc(s) { var d=document.createElement('div'); d.textContent=s; return d.innerHTML; }
function crown(isPremium) {
    if (!isPremium) return '';
    return '<span class="cm-crown-badge" title="Premium Member">👑</span>';
}

/* ══════════════════════════════════════
   POSTS
══════════════════════════════════════ */
function loadPosts(page, sort) {
    currentPage = page || 1;
    currentSort = sort || currentSort;
    var feed = document.getElementById('cmFeed');
    feed.innerHTML = '<div class="cm-loading"><div class="cm-spinner"></div></div>';

    fetch('community_api.php?action=get_posts&page=' + currentPage + '&sort=' + currentSort)
        .then(function(r){ return r.json(); })
        .then(function(data){
            totalPages = data.pages || 1;
            renderPosts(data.posts || []);
            renderPagination(data.total || 0);
            var el = document.getElementById('statPosts');
            if (el) el.textContent = data.total || 0;
        })
        .catch(function(){
            feed.innerHTML = '<p class="cm-error">Failed to load. Please refresh.</p>';
        });
}

function renderPosts(posts) {
    var feed = document.getElementById('cmFeed');
    if (!posts.length) {
        feed.innerHTML = '<div class="cm-empty"><div class="cm-empty-icon">💬</div><p>' + (cmT.cm_empty || 'No posts yet — start the conversation!') + '</p></div>';
        return;
    }
    feed.innerHTML = '';
    posts.forEach(function(p, i) {
        var replyLabel = p.reply_count + ' ' + (cmT.cm_replies || (p.reply_count===1?'reply':'replies'));
        var card = document.createElement('div');
        card.className = 'cm-post-card';
        card.style.animationDelay = (i * 0.06) + 's';
        card.innerHTML =
            '<div class="cm-post-meta">' +
                '<div class="cm-post-avatar">' + esc(av(p.author)) + '</div>' +
                '<div class="cm-post-author-info">' +
                    '<span class="cm-post-author">' + esc(p.author) + crown(p.is_premium) + '</span>' +
                    '<span class="cm-post-time">' + timeAgo(p.created_at) + '</span>' +
                '</div>' +
            '</div>' +
            '<h2 class="cm-post-title">' + esc(p.title) + '</h2>' +
            '<p class="cm-post-body">' + esc(p.body) + '</p>' +
            '<div class="cm-post-actions">' +
                '<button class="cm-like-btn ' + (p.i_liked?'liked':'') + '" data-id="' + p.id + '">' +
                    '<i class="' + (p.i_liked?'fas':'far') + ' fa-heart"></i>' +
                    '<span class="cm-like-count">' + p.likes + '</span>' +
                '</button>' +
                '<button class="cm-reply-open-btn" data-id="' + p.id + '" data-title="' + esc(p.title) + '" data-body="' + esc(p.body) + '" data-author="' + esc(p.author) + '">' +
                    '<i class="fas fa-comment-alt"></i>' +
                    '<span class="cm-reply-count-' + p.id + '">' + replyLabel + '</span>' +
                '</button>' +
                '<button class="cm-translate-btn">' +
                    '<i class="fas fa-language"></i> ' + (cmT.cm_translate || 'Translate') +
                '</button>' +
            '</div>';
        feed.appendChild(card);
    });

    feed.querySelectorAll('.cm-like-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            if (!CM_USER.isLoggedIn) { window.location.href='login.php'; return; }
            toggleLike(btn);
        });
    });
    feed.querySelectorAll('.cm-reply-open-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            openModal(btn.dataset.id, btn.dataset.title, btn.dataset.body, btn.dataset.author);
        });
    });
    feed.querySelectorAll('.cm-translate-btn').forEach(function(btn) {
        initTranslateBtn(btn);
    });
}

function renderPagination(total) {
    var pag = document.getElementById('cmPagination');
    pag.innerHTML = '';
    if (totalPages <= 1) return;
    for (var i = 1; i <= totalPages; i++) {
        var btn = document.createElement('button');
        btn.className = 'cm-page-btn' + (i===currentPage?' active':'');
        btn.textContent = i;
        btn.dataset.page = i;
        btn.addEventListener('click', function(){
            loadPosts(parseInt(this.dataset.page));
            window.scrollTo({top:0,behavior:'smooth'});
        });
        pag.appendChild(btn);
    }
}

function toggleLike(btn) {
    btn.disabled = true;
    fetch('community_api.php', {
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:'action=toggle_like&post_id='+btn.dataset.id
    }).then(function(r){return r.json();}).then(function(res){
        if (res.ok) {
            btn.classList.toggle('liked', res.liked);
            btn.querySelector('i').className = res.liked?'fas fa-heart':'far fa-heart';
            btn.querySelector('.cm-like-count').textContent = res.likes;
            btn.classList.add('cm-like-pop');
            setTimeout(function(){ btn.classList.remove('cm-like-pop'); }, 300);
        }
    }).finally(function(){ btn.disabled=false; });
}

/* ══════════════════════════════════════
   MODAL — Nested Replies
══════════════════════════════════════ */
function openModal(postId, title, body, author) {
    activePostId = postId;
    replyingTo   = null;
    document.getElementById('cmModalTitle').textContent = 'Replies';
    document.getElementById('cmModalPostPreview').innerHTML =
        '<div class="cm-preview-author">' + esc(author) + '</div>' +
        '<div class="cm-preview-title">' + esc(title) + '</div>' +
        '<div class="cm-preview-body">' + esc(body) + '</div>';

    resetReplyBox();
    document.getElementById('cmReplyModal').style.display = 'flex';
    document.body.style.overflow = 'hidden';
    loadReplies(postId);
}

function loadReplies(postId) {
    var container = document.getElementById('cmModalReplies');
    container.innerHTML = '<div class="cm-loading"><div class="cm-spinner"></div></div>';

    fetch('community_api.php?action=get_replies&post_id=' + postId)
        .then(function(r){ return r.json(); })
        .then(function(data){
            var replies = data.replies || [];
            if (!replies.length) {
                container.innerHTML = '<div class="cm-no-replies">' + (cmT.cm_empty || 'No replies yet — be the first! 💬') + '</div>';
                return;
            }
            // بنبني tree من flat array
            var tree = buildTree(replies);
            container.innerHTML = '';
            renderTree(tree, container, 0);
        });
}

/* بيحول الـ flat array لـ tree */
function buildTree(replies) {
    var map = {}, roots = [];
    replies.forEach(function(r) {
        r.children = [];
        map[r.id]  = r;
    });
    replies.forEach(function(r) {
        if (r.parent_id && map[r.parent_id]) {
            map[r.parent_id].children.push(r);
        } else {
            roots.push(r);
        }
    });
    return roots;
}

/* بيرسم الـ tree بشكل متداخل */
function renderTree(nodes, container, depth) {
    nodes.forEach(function(r) {
        var wrap = document.createElement('div');
        wrap.className = 'cm-reply-wrap';
        if (depth > 0) wrap.classList.add('cm-reply-nested');
        wrap.style.marginLeft = Math.min(depth, 4) * 24 + 'px';

        wrap.innerHTML =
            '<div class="cm-reply-card" data-id="' + r.id + '">' +
                '<div class="cm-reply-meta">' +
                    '<div class="cm-reply-avatar" style="background:' + depthColor(depth) + '">' + esc(av(r.author)) + '</div>' +
                    '<span class="cm-reply-author">' + esc(r.author) + crown(r.is_premium) + '</span>' +
                    '<span class="cm-reply-time">' + timeAgo(r.created_at) + '</span>' +
                    (depth > 0 ? '<span class="cm-reply-tag">↩ reply</span>' : '') +
                '</div>' +
                '<p class="cm-reply-body">' + esc(r.body) + '</p>' +
                '<div class="cm-reply-actions">' +
                (CM_USER.isLoggedIn ?
                    '<button class="cm-inline-reply-btn" data-id="' + r.id + '" data-author="' + esc(r.author) + '">' +
                        '<i class="fas fa-reply"></i> ' + (cmT.cm_reply_submit||'Reply') +
                    '</button>'
                : '') +
                '<button class="cm-translate-btn cm-translate-reply">' +
                    '<i class="fas fa-language"></i> ' + (cmT.cm_translate || 'Translate') +
                '</button>' +
                '</div>' +
            '</div>';

        container.appendChild(wrap);

        // اضغط Reply جوه الكارد
        var inlineBtn = wrap.querySelector('.cm-inline-reply-btn');
        if (inlineBtn) {
            inlineBtn.addEventListener('click', function() {
                setReplyingTo(r.id, r.author, wrap);
            });
        }

        var tBtn = wrap.querySelector('.cm-translate-btn');
        if (tBtn) initTranslateBtn(tBtn);

        // الـ children
        if (r.children && r.children.length) {
            var childContainer = document.createElement('div');
            childContainer.className = 'cm-children';
            wrap.appendChild(childContainer);
            renderTree(r.children, childContainer, depth + 1);
        }
    });
}

/* لون الـ avatar بيتغير حسب الـ depth */
function depthColor(depth) {
    var colors = [
        'linear-gradient(135deg,#1a56a0,#0ea5e9)',
        'linear-gradient(135deg,#0891b2,#06b6d4)',
        'linear-gradient(135deg,#0d9488,#14b8a6)',
        'linear-gradient(135deg,#7c3aed,#a78bfa)',
        'linear-gradient(135deg,#db2777,#f472b6)'
    ];
    return colors[Math.min(depth, colors.length-1)];
}

/* ── Translation Cache ── */
var translateCache = {};

function translateText(text, targetLang, callback) {
    var cacheKey = targetLang + '::' + text;
    if (translateCache[cacheKey]) { callback(null, translateCache[cacheKey]); return; }

    var langPair = targetLang === 'ar' ? 'en|ar' : 'ar|en';
    var url = 'https://api.mymemory.translated.net/get?q=' + encodeURIComponent(text) + '&langpair=' + langPair;

    fetch(url)
        .then(function(r) { return r.json(); })
        .then(function(data) {
            var translated = data.responseData && data.responseData.translatedText;
            if (translated) {
                translateCache[cacheKey] = translated;
                callback(null, translated);
            } else {
                callback('Translation unavailable');
            }
        })
        .catch(function() { callback('Network error'); });
}

/* ── Translate Button handler ── */
function initTranslateBtn(btn) {
    btn.addEventListener('click', function() {
        var card      = btn.closest('.cm-post-card, .cm-reply-card');
        var bodyEl    = card.querySelector('.cm-post-body, .cm-reply-body');
        var titleEl   = card.querySelector('.cm-post-title');   // posts only
        var isShowing = btn.dataset.translated === '1';
        var targetLang = cmLang === 'ar' ? 'ar' : 'en';

        if (isShowing) {
            // رجّع الأصلي
            bodyEl.textContent  = btn.dataset.origBody;
            if (titleEl) titleEl.textContent = btn.dataset.origTitle;
            btn.innerHTML = '<i class="fas fa-language"></i> ' + (cmT.cm_translate || 'Translate');
            btn.dataset.translated = '0';
            btn.classList.remove('cm-translate-active');
            return;
        }

        // خزّن النص الأصلي
        if (!btn.dataset.origBody) btn.dataset.origBody = bodyEl.textContent;
        if (titleEl && !btn.dataset.origTitle) btn.dataset.origTitle = titleEl.textContent;

        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> ' + (cmT.cm_translating || 'Translating...');
        btn.disabled = true;

        var toTranslate = (titleEl ? btn.dataset.origTitle + '\n' : '') + btn.dataset.origBody;

        translateText(toTranslate, targetLang, function(err, result) {
            btn.disabled = false;
            if (err) {
                btn.innerHTML = '<i class="fas fa-language"></i> ' + (cmT.cm_translate || 'Translate');
                return;
            }
            if (titleEl) {
                var parts = result.split('\n');
                titleEl.textContent = parts[0] || titleEl.textContent;
                bodyEl.textContent  = parts.slice(1).join('\n') || result;
            } else {
                bodyEl.textContent = result;
            }
            btn.innerHTML      = '<i class="fas fa-undo"></i> ' + (cmT.cm_show_original || 'Show original');
            btn.dataset.translated = '1';
            btn.classList.add('cm-translate-active');
        });
    });
}


function setReplyingTo(replyId, authorName, afterWrap) {
    replyingTo = { id: replyId, author: authorName };

    // أزّل أي inline form موجود
    var existing = document.querySelector('.cm-inline-form');
    if (existing) existing.remove();

    // أنشئ form صغير جوه الـ modal تحت الرد المختار
    var form = document.createElement('div');
    form.className = 'cm-inline-form';
    form.innerHTML =
        '<div class="cm-inline-form-header">' +
            '<span class="cm-replying-to-label">↩ ' + (cmT.cm_replying_to||'Replying to') + ' <strong>' + esc(authorName) + '</strong></span>' +
            '<button class="cm-cancel-inline">✕</button>' +
        '</div>' +
        '<div class="cm-inline-form-body">' +
            '<textarea class="cm-reply-input cm-inline-textarea" placeholder="' + (cmT.cm_reply_ph_inline||'Write your reply... (Ctrl+Enter to send)') + '" rows="3"></textarea>' +
            '<button class="cm-submit-btn cm-inline-submit"><i class="fas fa-reply"></i> ' + (cmT.cm_reply_submit||'Reply') + '</button>' +
        '</div>';

    afterWrap.appendChild(form);

    // Focus
    setTimeout(function(){ form.querySelector('textarea').focus(); }, 50);

    // Cancel
    form.querySelector('.cm-cancel-inline').addEventListener('click', function(){
        form.remove();
        replyingTo = null;
    });

    // Submit inline
    form.querySelector('.cm-inline-submit').addEventListener('click', function(){
        submitReply(form.querySelector('textarea').value, form);
    });

    form.querySelector('textarea').addEventListener('keydown', function(e){
        if (e.ctrlKey && e.key === 'Enter') submitReply(this.value, form);
    });
}

function resetReplyBox() {
    replyingTo = null;
    var existing = document.querySelector('.cm-inline-form');
    if (existing) existing.remove();
    var inp = document.getElementById('cmReplyBody');
    if (inp) inp.value = '';
    var lbl = document.getElementById('cmReplyingToLabel');
    if (lbl) lbl.style.display = 'none';
}

function submitReply(body, formEl) {
    body = (body || '').trim();
    if (!body || !activePostId) return;

    var submitBtn = formEl ? formEl.querySelector('.cm-submit-btn, .cm-reply-submit') : document.getElementById('cmSubmitReply');
    if (submitBtn) { submitBtn.disabled = true; submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>'; }

    var parentId = replyingTo ? replyingTo.id : 0;

    fetch('community_api.php', {
        method: 'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body: 'action=create_reply&post_id=' + activePostId +
              '&parent_id=' + parentId +
              '&body=' + encodeURIComponent(body)
    })
    .then(function(r){ return r.json(); })
    .then(function(res){
        if (res.ok) {
            // امسح الـ form
            if (formEl && formEl.classList.contains('cm-inline-form')) {
                formEl.remove();
            } else {
                var inp = document.getElementById('cmReplyBody');
                if (inp) inp.value = '';
            }
            replyingTo = null;
            // حدّث الردود
            loadReplies(activePostId);
            // حدّث العداد في الفيد
            var span = document.querySelector('.cm-reply-count-' + activePostId);
            if (span) {
                var cur  = parseInt(span.textContent) || 0;
                var next = cur + 1;
                span.textContent = next + ' ' + (next===1?'reply':'replies');
            }
        }
    })
    .finally(function(){
        if (submitBtn) { submitBtn.disabled=false; submitBtn.innerHTML='<i class="fas fa-reply"></i> Reply'; }
    });
}

function closeModal() {
    document.getElementById('cmReplyModal').style.display = 'none';
    document.body.style.overflow = '';
    activePostId = null;
    replyingTo   = null;
    var existing = document.querySelector('.cm-inline-form');
    if (existing) existing.remove();
}

/* ══════════════════════════════════════
   NEW POST
══════════════════════════════════════ */
function submitPost() {
    var title = (document.getElementById('cmPostTitle').value||'').trim();
    var body  = (document.getElementById('cmPostBody').value ||'').trim();
    if (!title||!body) { shake(document.getElementById('cmNewPost')); return; }

    var btn = document.getElementById('cmSubmitPost');
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Posting...';

    fetch('community_api.php', {
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:'action=create_post&title='+encodeURIComponent(title)+'&body='+encodeURIComponent(body)
    }).then(function(r){return r.json();}).then(function(res){
        if (res.ok) {
            document.getElementById('cmPostTitle').value='';
            document.getElementById('cmPostBody').value='';
            document.getElementById('cmNpForm').style.display='none';
            document.querySelectorAll('.cm-sort-btn').forEach(function(b){b.classList.remove('active');});
            document.querySelector('.cm-sort-btn[data-sort="new"]').classList.add('active');
            loadPosts(1,'new');
        }
    }).finally(function(){
        btn.disabled=false;
        btn.innerHTML='<i class="fas fa-paper-plane"></i> Post';
    });
}

function shake(el) {
    el.classList.add('cm-shake');
    setTimeout(function(){ el.classList.remove('cm-shake'); }, 500);
}

/* ══════════════════════════════════════
   INIT
══════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', function() {
    loadPosts(1);

    // Sort
    document.querySelectorAll('.cm-sort-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.cm-sort-btn').forEach(function(b){b.classList.remove('active');});
            btn.classList.add('active');
            loadPosts(1, btn.dataset.sort);
        });
    });

    // New post toggle
    var toggle = document.getElementById('cmNpToggle');
    if (toggle) toggle.addEventListener('click', function() {
        var f = document.getElementById('cmNpForm');
        f.style.display = f.style.display==='none'?'block':'none';
        if (f.style.display==='block') document.getElementById('cmPostTitle').focus();
    });

    var cancelBtn = document.getElementById('cmCancelPost');
    if (cancelBtn) cancelBtn.addEventListener('click', function() {
        document.getElementById('cmNpForm').style.display='none';
        document.getElementById('cmPostTitle').value='';
        document.getElementById('cmPostBody').value='';
    });

    var submitBtn = document.getElementById('cmSubmitPost');
    if (submitBtn) submitBtn.addEventListener('click', submitPost);

    var titleInp = document.getElementById('cmPostTitle');
    if (titleInp) titleInp.addEventListener('input', function(){
        document.getElementById('cmTitleCount').textContent = this.value.length+'/255';
    });

    // Modal close
    document.getElementById('cmModalClose').addEventListener('click', closeModal);
    document.getElementById('cmReplyModal').addEventListener('click', function(e){
        if (e.target===this) closeModal();
    });
    document.addEventListener('keydown', function(e){ if(e.key==='Escape') closeModal(); });

    // Main reply box (top-level reply)
    var mainReplyBtn = document.getElementById('cmSubmitReply');
    if (mainReplyBtn) mainReplyBtn.addEventListener('click', function(){
        var val = document.getElementById('cmReplyBody').value;
        submitReply(val, document.getElementById('cmReplyBody').closest('.cm-modal-reply-box'));
    });

    var mainReplyInp = document.getElementById('cmReplyBody');
    if (mainReplyInp) mainReplyInp.addEventListener('keydown', function(e){
        if (e.ctrlKey && e.key==='Enter') {
            submitReply(this.value, this.closest('.cm-modal-reply-box'));
        }
    });

    var postInp = document.getElementById('cmPostBody');
    if (postInp) postInp.addEventListener('keydown', function(e){
        if (e.ctrlKey && e.key==='Enter') submitPost();
    });

    // طبّق الترجمة فوراً من الـ hardcoded CM_TRANSLATIONS (مش محتاجين script.js)
    document.querySelectorAll('[data-key-ph]').forEach(function(el) {
        var key = el.getAttribute('data-key-ph');
        if (cmT[key]) el.placeholder = cmT[key];
    });
    var replyInpInit = document.getElementById('cmReplyBody');
    if (replyInpInit && cmT.cm_reply_ph) replyInpInit.placeholder = cmT.cm_reply_ph;

    // لو script.js جاهز كمان — دمج ترجماته
    setTimeout(function() {
        var savedLang = localStorage.getItem('language') || 'en';
        if (window.translations && window.translations[savedLang]) {
            cmSetLanguage(savedLang, window.translations[savedLang]);
        }
    }, 50);
});

})();